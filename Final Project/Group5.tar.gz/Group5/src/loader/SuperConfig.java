package loader;

public class SuperConfig {
	String workbookFileName;

	public SuperConfig() {
		workbookFileName = "/home/group5/workspace/Group5/LargeData.xls";
	}

	public SuperConfig(String workbookfilename) {
		workbookFileName = workbookfilename;
	}

}
